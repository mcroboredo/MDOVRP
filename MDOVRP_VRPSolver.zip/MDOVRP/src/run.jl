using VrpSolver, JuMP, ArgParse
# using CPLEX
include("data.jl")
include("model.jl")
include("solution.jl")

function convert_time(time)
   if time < 100
       return 0.0
   end 
   a = string(time)
   b = string(a[1:length(a)-2],".",a[length(a)-1:length(a)])
   return parse(Float64, b)
end

function parse_commandline(args_array::Array{String,1}, appfolder::String)
   s = ArgParseSettings(usage="##### VRPSolver #####\n\n"*
	   "  On interactive mode, call main([\"arg1\", ..., \"argn\"])", exit_after_help=false)
   @add_arg_table s begin
      "instance"
         help = "Instance file path"
      "--cfg", "-c"
         help = "Configuration file path"
         default = "$appfolder/../config/MDOVRP.cfg"
      "--ub","-u"
         help = "Upper bound (primal bound)"
         arg_type = Float64
         default = 10000000.0
      "--minr","-m"
         help = "Minimum number of routes in the solution"
         arg_type = Int
         default = 1 
      "--maxr","-M"
         help = "Maximum number of routes in the solution"
         arg_type = Int
         default = 999
      "--round","-r"
         help = "Does round the distance matrix?"
         action = :store_true
      "--out","-o"
         help = "Path to write the solution found"
      "--tikz","-t"
         help = "Path to write the TikZ figure of the solution found."
      "--batch","-b" 
         help = "batch file path" 
      "--Min_R","-R"
         help = "Change the Objective function to minimize the number of routes."
         action = :store_true
   end
   return parse_args(args_array, s)
end

function run_mdovrp(app::Dict{String,Any})

   println("Application parameters:")
   for (arg,val) in app
      println("  $arg  =>  $(repr(val))")
   end
   flush(stdout)

   #Getting the instance name
   instance_name = split(basename(app["instance"]), ".")[1]

   #Reading the instance file
   data = readMDOVRPData(app)
   
   solution_found = false
   #If the objective is only minimize the total distance
   if !app["Min_R"]
      
      (model, x) = build_model(data, app, 0) 
      optimizer = VrpOptimizer(model, app["cfg"], instance_name)
      set_cutoff!(optimizer, app["ub"]+0.1)
      (status, solution_found) = optimize!(optimizer)

      if solution_found
         sol = getsolution(data, optimizer, x, get_objective_value(optimizer), app)
      end
   #If the objective is first to minimze the number of routes to be used. The second objective is to minimize the distance
   else
      feasible = false
      # min_v indicates the optimal number of routes in the end of the algorithm
      min_v = initial_v = Int(ceil(sum(d(data, i) for i in customers(data))/veh_capacity(data)))
      accumulated_time = 0.0 # Total execution time in seconds
      optimization_time = 0.0 # Time of the last tree
      total_nodes = 0 # Total number of nodes consifering all trees

      while !feasible  
         #Running the current tree
         (model, x) = build_model(data, app, min_v)
         optimizer = VrpOptimizer(model, app["cfg"], instance_name)
         (status, solution_found) = optimize!(optimizer)
         #Getting the tree statistics
         optimization_time = convert_time(optimizer.stats[:bcTimeMain])
         accumulated_time += optimization_time
         total_nodes += optimizer.stats[:bcCountNodeProc]
         
         if solution_found
            feasible = true
         else
            if accumulated_time >= 18000
               println("Instance aborted: time limit of 18000 seconds is reached")
               feasible = true
            else
               min_v += 1
            end
         end

      end

      root_gap = -1.0 #Root gap of the last tree
      if solution_found
         sol = getsolution(data, optimizer, x, get_objective_value(optimizer), app)
         root_gap = 100*((sol.cost - optimizer.stats[:bcRecRootDb])/sol.cost)
         println("custom stats: & ", instance_name, " & ", initial_v, " & ", min_v, " & ", sol.cost, " & ", root_gap, " & ", total_nodes/(min_v - initial_v + 1), " & ", optimization_time, " & ", accumulated_time)
      else
         #Time limit is reached
         println("custom stats: & ", instance_name, " & ", initial_v, " & ", min_v, " & ", 0.0, " & ", root_gap, " & ", total_nodes/(min_v - initial_v + 1), " & ", optimization_time, " & ", accumulated_time)
      end

      #Showing customized statistics
      # Instance name, initial number of routes, optimal number of routes, cost of the Solution, last tree root gap, average number of nodes considering all trees, total time, time consumed by the last tree
      
   end

   println("########################################################")
   if solution_found  # Is there a solution?
      checksolution(data, sol) #Checking if the solution is feasible
      print_routes(sol) #Printing the solution
      if app["out"] != nothing
         writesolution(app["out"], sol) #Writting the solution in a file
      end
      if app["tikz"] != nothing
         drawsolution(app["tikz"], data, sol) # write tikz figure
      end
   else
      if status == :Optimal
         println("Problem infeasible")
      else
         println("Solution not found")
      end
   end
   println("########################################################")
end

function main(args)
   appfolder = dirname(@__FILE__)
   app = parse_commandline(args, appfolder)
   isnothing(app) && return
   if app["batch"] != nothing
      for line in readlines(app["batch"])
         if isempty(strip(line)) || strip(line)[1] == '#'
            continue
         end
         args_array = [String(s) for s in split(line)]
         app_line = parse_commandline(args_array, appfolder)
         run_mdovrp(app_line)
      end
   else
      run_mdovrp(app)
   end
end

if isempty(ARGS)
   main(["--help"])
else
   main(ARGS)
end
