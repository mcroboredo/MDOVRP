mutable struct Solution
   cost::Union{Int,Float64}
   routes::Array{Array{Int}}
end

# build Solution from the variables x
function getsolution(data::DataMDOVRP, optimizer::VrpOptimizer, x, objval, app::Dict{String,Any})
   routes = []
   for k in data.depot_ids
      for j in customers(data)
         e=(k,j)
         val = get_value(optimizer, x[e])
         curr = j
         if val > 0.5
            r = [k,curr]
            keep = true
            while keep
               keep = false
               for j in customers(data)
                  if j != curr
                     e = (curr,j)
                     val = get_value(optimizer, x[e])
                     if val > 0.5
                        curr = j
                        push!(r,j)
                        keep = true
                        break
                     end
                  end
               end

            end
            #@show r
            push!(routes, r)
         end
      end
   end
   if app["round"]
      objval = trunc(Int, round(objval))
   end
   return Solution(objval, routes)
end

# Print the solution
function print_routes(solution)
   cont = 1
   for r in solution.routes
      print("Route #", cont,": ")
      for i=1:length(r)
         if i != length(r)
            print(r[i], " ")
         else
            print(r[i])
         end
      end
      cont += 1
      println()
   end
   println("Cost $(solution.cost)")
end

# Check the feasiblity of a solution
function checksolution(data::DataMDOVRP, solution)

   visited = Dict() #visited[i] indicates the number of times that the customer i is visited. The solution is infeaible if visited[i] for some customer i 
   for i in customers(data)
      visited[i] = 0 
   end
   
   total_cost = 0.0
   for r in solution.routes
      #cheking if the first node is a depot
      if !(r[1] in data.depot_ids)
         println("error: The route does not start at depot ")
         @show r
      end
      
      
      if r[end] in data.depot_ids
         println("error: The route ends at depot ")
         @show r
      end
      
      
      cap = accum = 0.0
      for i=1:length(r)-1
         if !(r[i+1] in customers(data))
            println("error: the node in the middle of the route is not a customer")
            @show r
            @show r[i+1]
         else
            visited[r[i+1]] = visited[r[i+1]] + 1
         end

         cap += d(data,r[i+1])

         total_cost += c(data,(r[i],r[i+1]))

         
         if data.tw 
            accum += c(data,(r[i],r[i+1])) + st(data,r[i]) #arriving time at node i+1
            
            if accum < a(data,r[i+1])
               accum = a(data,r[i+1])
            end

            if (accum > b(data,r[i+1]))
               println("error: the time windows constraint is not respected")
               @show r
               @show r[i+1]
               @show a(data,r[i+1])
               @show b(data,r[i+1])
               @show accum
            end
         end
      end

      if cap > data.Q + 0.0001
         println("error: the capacity constraint is violated")
         @show r
         @show cap
         @show data.Q
      end
   end

   for i in customers(data)
      if visited[i] != 1
         println("error: ", i, " is visited ", visited[i], "times")
         @show solution.routes
      end
   end

   if ((total_cost > solution.cost + 0.0001) || (total_cost < solution.cost - 0.0001))
      println("error: the solution cost given by solution.cost is not equal to the cost calculated by the solution checker")
      println("solution.cost ", solution.cost) 
      println("solution calculated by the solution checker ", total_cost)
   end
end

# write solution in a file
function writesolution(solpath, solution)
   open(solpath, "w") do f
      for (i,r) in enumerate(solution.routes)
         write(f, "Route #$i: ")
         for j=1:length(r)
            #if j != r[end]
            
               k = r[j] + 1
               write(f, "$k ")
            #end 
         end
         write(f, "\n")
      end
      write(f, "Cost $(solution.cost)\n")
   end
end

# write solution as TikZ figure (.tex) 
function drawsolution(tikzpath, data, solution)
   open(tikzpath, "w") do f
      write(f,"\\documentclass[crop,tikz]{standalone}\n\\begin{document}\n")
      # get limits to draw
      pos_x_vals = [i.pos_x for i in data.G′.V′]
      pos_y_vals = [i.pos_y for i in data.G′.V′]
      scale_fac = 1/(max(maximum(pos_x_vals),maximum(pos_y_vals))/10)
      write(f,"\\begin{tikzpicture}[thick, scale=1, every node/.style={scale=0.3}]\n")
      for cid in customers(data)
         i = data.G′.V′[cid+1]
         x_plot = scale_fac*i.pos_x
         y_plot = scale_fac*i.pos_y
         write(f, "\t\\node[draw, line width=0.1mm, circle, fill=white, inner sep=0.05cm] (v$(i.id_vertex)) at ($(x_plot),$(y_plot)) {\\footnotesize $(i.id_vertex+1)};\n")
      end
      # draw depot   
      for did in data.depot_ids
         i = data.G′.V′[did+1]
         x_plot = scale_fac*i.pos_x
         y_plot = scale_fac*i.pos_y
         write(f, "\t\\node[draw, line width=0.1mm, rectangle, fill=yellow, inner sep=0.05cm, scale=1.4] (v$(i.id_vertex)) at ($(x_plot),$(y_plot)) {\\footnotesize $(i.id_vertex+1)};\n")
      end
      for r in solution.routes
         prev = r[1]
         for i in r[2:end]
            e = (prev,i) 
            #if !(i in data.depot_ids)           
            write(f, "\t\\draw[-,line width=0.8pt] (v$(e[1])) -- (v$(e[2]));\n")
            prev = i
         end
         #write(f, "\t\\draw[-,line width=0.8pt] (v$(r[end])) -- (v$(prev));\n") 
      end
      write(f, "\\end{tikzpicture}\n")
      write(f, "\\end{document}\n")
   end   
end
