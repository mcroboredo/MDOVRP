function build_model(data::DataMDOVRP, app::Dict{String,Any}, nv::Int64)

   #If nv = 0 we are only minimizing the total distance. Otherwise, nv indicates the number of vehicles to be fixed.
   A = arcs(data) #Set of arcs
   n = nb_customers(data) #Number of customers
   V⁺ = customers(data) #Set of customers
   Q = veh_capacity(data) #Vehicle capacity
   tw = data.tw #Time windows?

   # Formulation
   mdovrp = VrpModel()
   @variable(mdovrp.formulation, x[a in A], Int)
   @objective(mdovrp.formulation, Min, sum(c(data,a) * x[a] for a in A))    
   @constraint(mdovrp.formulation, deg[i in V⁺], sum(x[a] for a in δ⁻(data, i)) == 1.0)



   #Path generator graph
   function build_graph()
      V = vcat([V⁺[end]+1],data.depot_ids, V⁺) # set of vertices of G
      
      v_source = v_sink = V⁺[end]+1

      if nv == 0
         L = max(app["minr"], 0)
         U = min(app["maxr"], n)
      else
         L = U = nv
      end

      #creating the path generator graph G
      G = VrpGraph(mdovrp, V, v_source, v_sink, (L, U))
      
      #adding the resource to ensure the capacity constraint.
      cap_res_id = add_resource!(G, main = true) 

      #If the problem considers considers time windows constraints, then we create a resource to ensure these constraints.
      if tw
         time_res_id = add_resource!(G, main = true)
      end

      #Adding the bounds for each resource and each interval.
      for i in V
         set_resource_bounds!(G, i, cap_res_id, 0.0, Float64(Q))
         if tw
            if i == v_source || i == v_sink
               set_resource_bounds!(G, i, time_res_id, a(data,0), b(data,0))
            else
               set_resource_bounds!(G, i, time_res_id, a(data,i), b(data,i))
            end
         end
      end

      #Creating an arc from the v_source to each depot. There is no resouce consumption for these arcs
      for k in data.depot_ids
         arc_id = add_arc!(G, v_source, k)
      end

      #Creating an arc from each customer to v_sink
      for j in V⁺
         arc_id = add_arc!(G, j, v_sink)
         set_arc_consumption!(G, arc_id, cap_res_id, d(data, j)/2)
         if tw 
            set_arc_consumption!(G, arc_id, time_res_id, st(data,j))
         end
      end

      # set of arcs from depots to customers
      for k in data.depot_ids
         for j in V⁺
            arc_id = add_arc!(G, k, j)
            add_arc_var_mapping!(G, arc_id, [x[(k,j)]])
            set_arc_consumption!(G, arc_id, cap_res_id, d(data, j)/2)
            if tw
               set_arc_consumption!(G, arc_id, time_res_id, c(data,(k, j)))
            end
         end
      end

      # set of arcs between customers
      for i in V⁺
         for j in V⁺
            if i < j
               arc_id = add_arc!(G, i, j)
               add_arc_var_mapping!(G, arc_id, x[(i,j)])
               set_arc_consumption!(G, arc_id, cap_res_id, (d(data, i) + d(data, j))/2)
               if tw 
                  #@show i, j, st(data,i), distance(data,(i, j)), st(data,i) + distance(data,(i, j))
                  set_arc_consumption!(G, arc_id, time_res_id, st(data,i) + distance(data,(i, j)))
               end
               arc_id = add_arc!(G, j, i)
               add_arc_var_mapping!(G, arc_id, x[(j,i)])
               set_arc_consumption!(G, arc_id, cap_res_id, (d(data, i) + d(data, j))/2)
               if tw
                  #@show j, i, st(data,j), distance(data,(j, i)), st(data,j) + distance(data,(j, i))
                  set_arc_consumption!(G, arc_id, time_res_id, st(data,j) + distance(data,(j, i)))
               end
            end
         end
      end

      return G
   end

   G = build_graph()
   add_graph!(mdovrp, G)
   
   set_vertex_packing_sets!(mdovrp, [[(G,i)] for i in V⁺])
   define_elementarity_sets_distance_matrix!(mdovrp, G, [[distance(data, (i, j)) for j in V⁺] for i in V⁺])
   add_capacity_cut_separator!(mdovrp, [ ( [(G,i)], d(data, i) ) for i in V⁺], Q)
   set_branching_priority!(mdovrp, "x", 1)

   return (mdovrp, x)
end


